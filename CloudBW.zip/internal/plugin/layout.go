package plugin

import (
	"context"
	"encoding/json"
	"fmt"
)

type ComponentType string

const (
	ComponentTypeWidget    ComponentType = "widget"
	ComponentTypeLayout    ComponentType = "layout"
	ComponentTypePanel     ComponentType = "panel"
	ComponentTypeModal     ComponentType = "modal"
	ComponentTypeForm      ComponentType = "form"
	ComponentTypeList      ComponentType = "list"
	ComponentTypeToolbar   ComponentType = "toolbar"
	ComponentTypePreview   ComponentType = "preview"
)

type ComponentSchema struct {
	ID          string                 `json:"id"`
	Name        string                 `json:"name"`
	Type        ComponentType          `json:"type"`
	Description string                 `json:"description"`
	Icon        string                 `json:"icon"`
	Category    string                 `json:"category"`
	Props       []ComponentProp        `json:"props"`
	Events      []ComponentEvent       `json:"events"`
	Slots       []ComponentSlot        `json:"slots,omitempty"`
	Children    []ComponentSchema      `json:"children,omitempty"`
}

type ComponentProp struct {
	Name        string      `json:"name"`
	Type        string      `json:"type"`
	Label       string      `json:"label"`
	Default     interface{} `json:"default"`
	Required    bool        `json:"required"`
	Options     []PropOption `json:"options,omitempty"`
}

type PropOption struct {
	Label string `json:"label"`
	Value string `json:"value"`
}

type ComponentEvent struct {
	Name        string `json:"name"`
	Description string `json:"description"`
}

type ComponentSlot struct {
	Name        string `json:"name"`
	Description string `json:"description"`
}

type ComponentInstance struct {
	ID         string                 `json:"id"`
	Component  string                 `json:"component"`
	Props      map[string]interface{} `json:"props"`
	Style      map[string]string      `json:"style"`
	Children   []ComponentInstance    `json:"children,omitempty"`
	Slot       string                 `json:"slot,omitempty"`
}

type PageLayout struct {
	ID          string             `json:"id"`
	Name        string             `json:"name"`
	Description string             `json:"description"`
	Components  []ComponentInstance `json:"components"`
}

type LayoutManager struct {
	pages   map[string]*PageLayout
	layouts map[string]*ComponentSchema
}

var layoutManager *LayoutManager

func GetLayoutManager() *LayoutManager {
	if layoutManager == nil {
		layoutManager = &LayoutManager{
			pages:   make(map[string]*PageLayout),
			layouts: make(map[string]*ComponentSchema),
		}
	}
	return layoutManager
}

func (lm *LayoutManager) RegisterComponent(schema ComponentSchema) {
	lm.layouts[schema.ID] = &schema
}

func (lm *LayoutManager) GetComponentSchema(id string) (*ComponentSchema, bool) {
	schema, exists := lm.layouts[id]
	return schema, exists
}

func (lm *LayoutManager) ListComponents() []ComponentSchema {
	list := make([]ComponentSchema, 0, len(lm.layouts))
	for _, schema := range lm.layouts {
		list = append(list, *schema)
	}
	return list
}

func (lm *LayoutManager) CreatePage(layout PageLayout) error {
	if _, exists := lm.pages[layout.ID]; exists {
		return fmt.Errorf("page %s already exists", layout.ID)
	}
	lm.pages[layout.ID] = &layout
	return nil
}

func (lm *LayoutManager) GetPage(id string) (*PageLayout, bool) {
	page, exists := lm.pages[id]
	return page, exists
}

func (lm *LayoutManager) UpdatePage(layout PageLayout) error {
	if _, exists := lm.pages[layout.ID]; !exists {
		return fmt.Errorf("page %s not found", layout.ID)
	}
	lm.pages[layout.ID] = &layout
	return nil
}

func (lm *LayoutManager) DeletePage(id string) error {
	if _, exists := lm.pages[id]; !exists {
		return fmt.Errorf("page %s not found", id)
	}
	delete(lm.pages, id)
	return nil
}

func (lm *LayoutManager) RenderPage(ctx context.Context, pageID string) (string, error) {
	page, exists := lm.pages[pageID]
	if !exists {
		return "", fmt.Errorf("page %s not found", pageID)
	}

	return lm.RenderComponents(ctx, page.Components)
}

func (lm *LayoutManager) RenderComponents(ctx context.Context, components []ComponentInstance) (string, error) {
	var result string
	for _, comp := range components {
		rendered, err := lm.RenderComponent(ctx, comp)
		if err != nil {
			return "", err
		}
		result += rendered
	}
	return result, nil
}

func (lm *LayoutManager) RenderComponent(ctx context.Context, instance ComponentInstance) (string, error) {
	schema, exists := lm.layouts[instance.Component]
	if !exists {
		return "", fmt.Errorf("component %s not found", instance.Component)
	}

	data := map[string]interface{}{
		"id":       instance.ID,
		"component": schema.ID,
		"props":    instance.Props,
		"style":    instance.Style,
	}

	if len(instance.Children) > 0 {
		children, err := lm.RenderComponents(ctx, instance.Children)
		if err != nil {
			return "", err
		}
		data["children"] = children
	}

	jsonData, err := json.Marshal(data)
	if err != nil {
		return "", err
	}

	return string(jsonData), nil
}

func (lm *LayoutManager) GetComponentPropsSchema(componentID string) ([]ComponentProp, error) {
	schema, exists := lm.layouts[componentID]
	if !exists {
		return nil, fmt.Errorf("component %s not found", componentID)
	}
	return schema.Props, nil
}

func (lm *LayoutManager) ValidateComponent(instance ComponentInstance) error {
	schema, exists := lm.layouts[instance.Component]
	if !exists {
		return fmt.Errorf("component %s not found", instance.Component)
	}

	for _, prop := range schema.Props {
		if prop.Required {
			if _, exists := instance.Props[prop.Name]; !exists {
				return fmt.Errorf("required prop %s missing for component %s", prop.Name, instance.Component)
			}
		}
	}

	return nil
}

var DefaultComponents = []ComponentSchema{
	{
		ID:          "file-list",
		Name:        "File List",
		Type:        ComponentTypeList,
		Description: "Display a list of files",
		Icon:        "folder",
		Category:    "file",
		Props: []ComponentProp{
			{Name: "folderId", Type: "string", Label: "Folder ID", Required: false},
			{Name: "viewMode", Type: "string", Label: "View Mode", Default: "grid", Options: []PropOption{{Label: "Grid", Value: "grid"}, {Label: "List", Value: "list"}}},
			{Name: "sortBy", Type: "string", Label: "Sort By", Default: "name"},
		},
		Events: []ComponentEvent{{Name: "fileClick", Description: "Triggered when a file is clicked"}},
	},
	{
		ID:          "upload-button",
		Name:        "Upload Button",
		Type:        ComponentTypeWidget,
		Description: "Button to upload files",
		Icon:        "upload",
		Category:    "action",
		Props: []ComponentProp{
			{Name: "label", Type: "string", Label: "Button Label", Default: "Upload"},
			{Name: "multiple", Type: "boolean", Label: "Allow Multiple", Default: true},
			{Name: "accept", Type: "string", Label: "Accepted Types", Default: "*"},
		},
		Events: []ComponentEvent{{Name: "uploadComplete", Description: "Triggered when upload completes"}},
	},
	{
		ID:          "storage-info",
		Name:        "Storage Info",
		Type:        ComponentTypeWidget,
		Description: "Display storage usage information",
		Icon:        "harddrive",
		Category:    "info",
		Props: []ComponentProp{
			{Name: "showUsed", Type: "boolean", Label: "Show Used", Default: true},
			{Name: "showAvailable", Type: "boolean", Label: "Show Available", Default: true},
			{Name: "showPercent", Type: "boolean", Label: "Show Percentage", Default: true},
		},
	},
	{
		ID:          "share-panel",
		Name:        "Share Panel",
		Type:        ComponentTypePanel,
		Description: "Panel for managing file shares",
		Icon:        "share",
		Category:    "action",
		Props: []ComponentProp{
			{Name: "fileId", Type: "string", Label: "File ID"},
			{Name: "expireDays", Type: "number", Label: "Expire Days", Default: 7},
			{Name: "allowDownload", Type: "boolean", Label: "Allow Download", Default: true},
		},
		Events: []ComponentEvent{{Name: "shareCreated", Description: "Triggered when share is created"}},
	},
	{
		ID:          "search-bar",
		Name:        "Search Bar",
		Type:        ComponentTypeWidget,
		Description: "Search bar for files and folders",
		Icon:        "search",
		Category:    "navigation",
		Props: []ComponentProp{
			{Name: "placeholder", Type: "string", Label: "Placeholder", Default: "Search..."},
			{Name: "debounce", Type: "number", Label: "Debounce (ms)", Default: 300},
			{Name: "showAdvanced", Type: "boolean", Label: "Show Advanced", Default: false},
		},
		Events: []ComponentEvent{{Name: "search", Description: "Triggered on search"}},
	},
	{
		ID:          "preview-modal",
		Name:        "Preview Modal",
		Type:        ComponentTypeModal,
		Description: "Modal for file preview",
		Icon:        "eye",
		Category:    "view",
		Props: []ComponentProp{
			{Name: "fileId", Type: "string", Label: "File ID"},
			{Name: "showDownload", Type: "boolean", Label: "Show Download Button", Default: true},
			{Name: "showShare", Type: "boolean", Label: "Show Share Button", Default: true},
		},
		Events: []ComponentEvent{{Name: "close", Description: "Triggered when modal closes"}},
	},
}

func InitDefaultComponents() {
	lm := GetLayoutManager()
	for _, comp := range DefaultComponents {
		lm.RegisterComponent(comp)
	}
}