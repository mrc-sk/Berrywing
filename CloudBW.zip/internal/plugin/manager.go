package plugin

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"plugin"
	"sync"

	"github.com/cloudberrywing/cloudbw/pkg/logger"
)

type Plugin interface {
	Name() string
	Version() string
	Description() string
	Init() error
	Shutdown() error
}

type PluginManager struct {
	plugins map[string]Plugin
	mutex   sync.RWMutex
}

var manager *PluginManager
var once sync.Once

func GetPluginManager() *PluginManager {
	once.Do(func() {
		manager = &PluginManager{
			plugins: make(map[string]Plugin),
		}
	})
	return manager
}

func (pm *PluginManager) LoadPlugins(path string) error {
	files, err := filepath.Glob(filepath.Join(path, "*.so"))
	if err != nil {
		return err
	}

	for _, file := range files {
		if err := pm.LoadPlugin(file); err != nil {
			logger.Warn("Failed to load plugin", logger.String("file", file), logger.Error(err))
		}
	}

	return nil
}

func (pm *PluginManager) LoadPlugin(path string) error {
	pm.mutex.Lock()
	defer pm.mutex.Unlock()

	plug, err := plugin.Open(path)
	if err != nil {
		return fmt.Errorf("failed to open plugin %s: %v", path, err)
	}

	sym, err := plug.Lookup("Plugin")
	if err != nil {
		return fmt.Errorf("failed to find Plugin symbol: %v", err)
	}

	p, ok := sym.(Plugin)
	if !ok {
		return fmt.Errorf("invalid plugin type")
	}

	if err := p.Init(); err != nil {
		return fmt.Errorf("failed to initialize plugin %s: %v", p.Name(), err)
	}

	pm.plugins[p.Name()] = p
	logger.Info("Plugin loaded", logger.String("name", p.Name()), logger.String("version", p.Version()))

	return nil
}

func (pm *PluginManager) UnloadPlugin(name string) error {
	pm.mutex.Lock()
	defer pm.mutex.Unlock()

	p, exists := pm.plugins[name]
	if !exists {
		return fmt.Errorf("plugin %s not found", name)
	}

	if err := p.Shutdown(); err != nil {
		return fmt.Errorf("failed to shutdown plugin %s: %v", name, err)
	}

	delete(pm.plugins, name)
	logger.Info("Plugin unloaded", logger.String("name", name))

	return nil
}

func (pm *PluginManager) GetPlugin(name string) (Plugin, bool) {
	pm.mutex.RLock()
	defer pm.mutex.RUnlock()

	p, exists := pm.plugins[name]
	return p, exists
}

func (pm *PluginManager) ListPlugins() []Plugin {
	pm.mutex.RLock()
	defer pm.mutex.RUnlock()

	list := make([]Plugin, 0, len(pm.plugins))
	for _, p := range pm.plugins {
		list = append(list, p)
	}

	return list
}

func (pm *PluginManager) GetPluginInfo(name string) map[string]interface{} {
	p, exists := pm.GetPlugin(name)
	if !exists {
		return nil
	}

	return map[string]interface{}{
		"name":        p.Name(),
		"version":     p.Version(),
		"description": p.Description(),
	}
}

func (pm *PluginManager) EnablePlugin(name string) error {
	_, exists := pm.GetPlugin(name)
	if !exists {
		return fmt.Errorf("plugin %s not found", name)
	}
	return nil
}

func (pm *PluginManager) DisablePlugin(name string) error {
	return pm.UnloadPlugin(name)
}

func (pm *PluginManager) ReloadPlugin(name string) error {
	if err := pm.UnloadPlugin(name); err != nil {
		logger.Warn("Failed to unload plugin", logger.String("name", name), logger.Error(err))
	}

	return nil
}

func InitPlugins(pluginDir string) error {
	if err := os.MkdirAll(pluginDir, 0755); err != nil {
		return err
	}

	return GetPluginManager().LoadPlugins(pluginDir)
}

func ShutdownPlugins() {
	pm := GetPluginManager()
	for name := range pm.plugins {
		pm.UnloadPlugin(name)
	}
}

type UIComponent interface {
	Plugin
	Render(ctx context.Context) (string, error)
	GetComponentName() string
	GetComponentCategory() string
}

type StorageDriver interface {
	Plugin
	GetStorageType() string
}

type TaskHandler interface {
	Plugin
	HandleTask(taskType string, data map[string]interface{}) error
}