package router

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/cloudberrywing/cloudbw/internal/aria2"
	"github.com/cloudberrywing/cloudbw/internal/config"
	"github.com/cloudberrywing/cloudbw/internal/handlers"
	"github.com/cloudberrywing/cloudbw/internal/middleware"
	"github.com/cloudberrywing/cloudbw/internal/plugin"
	"github.com/cloudberrywing/cloudbw/internal/preview"
	"github.com/cloudberrywing/cloudbw/internal/webdav"
	"github.com/cloudberrywing/cloudbw/pkg/logger"
)

func SetupRouter() *gin.Engine {
	r := gin.New()
	r.Use(gin.Recovery())
	r.Use(middleware.Logger())
	r.Use(middleware.CORS())

	setupWebDAV(r)
	setupPreview(r)

	api := r.Group("/api/v1")
	{
		auth := api.Group("/auth")
		{
			auth.POST("/register", handlers.Register)
			auth.POST("/login", handlers.Login)
			auth.POST("/logout", handlers.Logout)
		}

		file := api.Group("/files")
		file.Use(middleware.AuthRequired())
		{
			file.GET("/list", handlers.ListFiles)
			file.POST("/upload", handlers.UploadFile)
			file.GET("/download/:id", handlers.DownloadFile)
			file.DELETE("/:id", handlers.DeleteFile)
			file.GET("/:id", handlers.GetFileInfo)
			file.PUT("/:id", handlers.UpdateFile)
			file.GET("/preview/:id", handlers.PreviewFile)
		}

		folder := api.Group("/folders")
		folder.Use(middleware.AuthRequired())
		{
			folder.GET("/list", handlers.ListFolders)
			folder.POST("/create", handlers.CreateFolder)
			folder.DELETE("/:id", handlers.DeleteFolder)
			folder.GET("/:id", handlers.GetFolderInfo)
			folder.PUT("/:id", handlers.UpdateFolder)
		}

		share := api.Group("/shares")
		{
			share.GET("/:token", handlers.GetShare)
			share.POST("/create", middleware.AuthRequired(), handlers.CreateShare)
			share.DELETE("/:id", middleware.AuthRequired(), handlers.DeleteShare)
		}

		storage := api.Group("/storage")
		storage.Use(middleware.AuthRequired())
		{
			storage.GET("/info", handlers.GetStorageInfo)
			storage.GET("/policies", handlers.ListStoragePolicies)
			storage.POST("/policies", handlers.CreateStoragePolicy)
		}

		user := api.Group("/user")
		user.Use(middleware.AuthRequired())
		{
			user.GET("/info", handlers.GetUserInfo)
			user.PUT("/info", handlers.UpdateUserInfo)
			user.GET("/settings", handlers.GetUserSettings)
			user.PUT("/settings", handlers.UpdateUserSettings)
		}

		download := api.Group("/downloads")
		download.Use(middleware.AuthRequired())
		{
			download.POST("/add", handlers.AddDownload)
			download.GET("/list", handlers.ListDownloads)
			download.GET("/:gid", handlers.GetDownload)
			download.DELETE("/:gid", handlers.RemoveDownload)
			download.POST("/:gid/pause", handlers.PauseDownload)
			download.POST("/:gid/resume", handlers.ResumeDownload)
		}

		pluginAPI := api.Group("/plugins")
		pluginAPI.Use(middleware.AuthRequired())
		{
			pluginAPI.GET("/list", handlers.ListPlugins)
			pluginAPI.GET("/:name", handlers.GetPlugin)
			pluginAPI.POST("/:name/enable", handlers.EnablePlugin)
			pluginAPI.POST("/:name/disable", handlers.DisablePlugin)
			pluginAPI.POST("/reload", handlers.ReloadPlugins)
		}

		layout := api.Group("/layout")
		layout.Use(middleware.AuthRequired())
		{
			layout.GET("/components", handlers.ListComponents)
			layout.GET("/components/:id", handlers.GetComponentSchema)
			layout.GET("/pages", handlers.ListPages)
			layout.GET("/pages/:id", handlers.GetPage)
			layout.POST("/pages", handlers.CreatePage)
			layout.PUT("/pages/:id", handlers.UpdatePage)
			layout.DELETE("/pages/:id", handlers.DeletePage)
			layout.POST("/render/:id", handlers.RenderPage)
		}
	}

	return r
}

func setupWebDAV(r *gin.Engine) {
	r.Any("/dav/*path", func(c *gin.Context) {
		handler := webdav.NewHandler()
		req := c.Request
		w := c.Writer

		req.URL.Path = "/dav" + c.Param("path")

		handler.ServeHTTP(w, req)
	})
	logger.Info("WebDAV routes registered")
}

func setupPreview(r *gin.Engine) {
	previewHandler := preview.NewHandler()
	r.GET("/preview/:id", func(c *gin.Context) {
		req := c.Request
		w := c.Writer

		req.URL.Path = "/" + c.Param("id")
		previewHandler.ServeHTTP(w, req)
	})
	logger.Info("Preview routes registered")
}

var downloadManager *aria2.DownloadManager

func InitDownloadManager() {
	aria2Config := config.Cfg.Aria2
	if aria2Config.Enabled {
		downloadManager = aria2.NewDownloadManager(aria2Config.Endpoint, aria2Config.Secret)
		downloadManager.StartMonitor(5 * 1e9)
		logger.Info("Download manager initialized")
	}
}

func GetDownloadManager() *aria2.DownloadManager {
	return downloadManager
}