package webdav

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"os"
	"path"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"github.com/cloudberrywing/cloudbw/internal/config"
	"github.com/cloudberrywing/cloudbw/internal/models"
	"github.com/cloudberrywing/cloudbw/internal/services"
	"github.com/cloudberrywing/cloudbw/pkg/logger"
)

type Handler struct{}

func NewHandler() *Handler {
	return &Handler{}
}

func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	userID := r.Context().Value("userID").(uint)

	switch r.Method {
	case "OPTIONS":
		h.handleOptions(w, r)
	case "PROPFIND":
		h.handlePropfind(w, r, userID)
	case "MKCOL":
		h.handleMkcol(w, r, userID)
	case "GET":
		h.handleGet(w, r, userID)
	case "PUT":
		h.handlePut(w, r, userID)
	case "DELETE":
		h.handleDelete(w, r, userID)
	case "COPY":
		h.handleCopy(w, r, userID)
	case "MOVE":
		h.handleMove(w, r, userID)
	case "LOCK":
		h.handleLock(w, r, userID)
	case "UNLOCK":
		h.handleUnlock(w, r, userID)
	default:
		http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
	}
}

func (h *Handler) handleOptions(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("DAV", "1, 2")
	w.Header().Set("Allow", "OPTIONS, PROPFIND, MKCOL, GET, PUT, DELETE, COPY, MOVE, LOCK, UNLOCK")
	w.WriteHeader(http.StatusOK)
}

func (h *Handler) handlePropfind(w http.ResponseWriter, r *http.Request, userID uint) {
	depth := r.Header.Get("Depth")
	if depth == "" {
		depth = "0"
	}

	pathInfo := r.URL.Path
	if pathInfo == "/" {
		pathInfo = ""
	}

	resp := h.generatePropfindResponse(pathInfo, depth, userID)
	w.Header().Set("Content-Type", "application/xml; charset=utf-8")
	w.WriteHeader(http.StatusMultiStatus)
	w.Write([]byte(resp))
}

func (h *Handler) generatePropfindResponse(reqPath, depth string, userID uint) string {
	var response strings.Builder
	response.WriteString(`<?xml version="1.0" encoding="UTF-8"?>`)
	response.WriteString(`<D:multistatus xmlns:D="DAV:">`)

	folders, _ := services.ListFolders(userID, 0)
	files, _ := services.ListFiles(userID, 0)

	basePath := reqPath
	if basePath == "" {
		response.WriteString(fmt.Sprintf(`<D:response><D:href>/%s</D:href>`, reqPath))
		response.WriteString(`<D:propstat><D:prop><D:resourcetype><D:collection/></D:resourcetype>`)
		response.WriteString(`<D:displayname>/</D:displayname>`)
		response.WriteString(`<D:getlastmodified>` + time.Now().Format(time.RFC1123) + `</D:getlastmodified>`)
		response.WriteString(`<D:getcontentlength>0</D:getcontentlength>`)
		response.WriteString(`<D:getcontenttype>httpd/unix-directory</D:getcontenttype>`)
		response.WriteString(`</D:prop><D:status>HTTP/1.1 200 OK</D:status></D:propstat></D:response>`)
	}

	if depth != "0" {
		for _, folder := range folders {
			if folder.ParentID == nil || *folder.ParentID == 0 {
				folderPath := filepath.Join(basePath, folder.Name)
				response.WriteString(fmt.Sprintf(`<D:response><D:href>/%s</D:href>`, folderPath))
				response.WriteString(`<D:propstat><D:prop><D:resourcetype><D:collection/></D:resourcetype>`)
				response.WriteString(fmt.Sprintf(`<D:displayname>%s</D:displayname>`, escapeXML(folder.Name)))
				response.WriteString(`<D:getlastmodified>` + folder.UpdatedAt.Format(time.RFC1123) + `</D:getlastmodified>`)
				response.WriteString(`<D:getcontentlength>0</D:getcontentlength>`)
				response.WriteString(`<D:getcontenttype>httpd/unix-directory</D:getcontenttype>`)
				response.WriteString(`</D:prop><D:status>HTTP/1.1 200 OK</D:status></D:propstat></D:response>`)
			}
		}

		for _, file := range files {
			if file.ParentID == nil || *file.ParentID == 0 {
				filePath := filepath.Join(basePath, file.Name)
				response.WriteString(fmt.Sprintf(`<D:response><D:href>/%s</D:href>`, filePath))
				response.WriteString(`<D:propstat><D:prop><D:resourcetype/></D:prop>`)
				response.WriteString(fmt.Sprintf(`<D:displayname>%s</D:displayname>`, escapeXML(file.Name)))
				response.WriteString(`<D:getlastmodified>` + file.UpdatedAt.Format(time.RFC1123) + `</D:getlastmodified>`)
				response.WriteString(fmt.Sprintf(`<D:getcontentlength>%d</D:getcontentlength>`, file.Size))
				response.WriteString(fmt.Sprintf(`<D:getcontenttype>%s</D:getcontenttype>`, file.MimeType))
				response.WriteString(`</D:prop><D:status>HTTP/1.1 200 OK</D:status></D:propstat></D:response>`)
			}
		}
	}

	response.WriteString(`</D:multistatus>`)
	return response.String()
}

func escapeXML(s string) string {
	s = strings.ReplaceAll(s, "&", "&amp;")
	s = strings.ReplaceAll(s, "<", "&lt;")
	s = strings.ReplaceAll(s, ">", "&gt;")
	s = strings.ReplaceAll(s, "\"", "&quot;")
	s = strings.ReplaceAll(s, "'", "&apos;")
	return s
}

func (h *Handler) handleMkcol(w http.ResponseWriter, r *http.Request, userID uint) {
	folderPath := r.URL.Path
	folderPath = strings.TrimPrefix(folderPath, "/")

	parts := strings.Split(folderPath, "/")
	if len(parts) == 0 {
		http.Error(w, "Invalid path", http.StatusBadRequest)
		return
	}

	name := parts[len(parts)-1]

	_, err := services.CreateFolder(userID, 0, name)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusCreated)
}

func (h *Handler) handleGet(w http.ResponseWriter, r *http.Request, userID uint) {
	filePath := r.URL.Path
	filePath = strings.TrimPrefix(filePath, "/")

	if filePath == "" {
		h.handlePropfind(w, r, userID)
		return
	}

	files, _ := services.ListFiles(userID, 0)
	for _, file := range files {
		if file.Name == filePath {
			http.ServeFile(w, r, file.Path)
			return
		}
	}

	http.Error(w, "File not found", http.StatusNotFound)
}

func (h *Handler) handlePut(w http.ResponseWriter, r *http.Request, userID uint) {
	filePath := r.URL.Path
	filePath = strings.TrimPrefix(filePath, "/")

	filename := path.Base(filePath)

	contentLength, _ := strconv.ParseInt(r.Header.Get("Content-Length"), 10, 64)

	storagePath := config.Cfg.Storage.Path
	if err := os.MkdirAll(storagePath, 0755); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	dstPath := filepath.Join(storagePath, filename)
	dst, err := os.Create(dstPath)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	defer dst.Close()

	_, err = io.CopyN(dst, r.Body, contentLength)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	file := &models.File{
		Name:       filename,
		Size:       contentLength,
		Path:       dstPath,
		OwnerID:    userID,
		MimeType:   r.Header.Get("Content-Type"),
		Extension:  path.Ext(filename),
		UploadedAt: time.Now(),
	}

	if err := services.DB.Create(file).Error; err != nil {
		os.Remove(dstPath)
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusCreated)
}

func (h *Handler) handleDelete(w http.ResponseWriter, r *http.Request, userID uint) {
	filePath := r.URL.Path
	filePath = strings.TrimPrefix(filePath, "/")

	files, _ := services.ListFiles(userID, 0)
	for _, file := range files {
		if file.Name == filePath {
			if err := services.DeleteFile(file.ID, userID); err != nil {
				http.Error(w, err.Error(), http.StatusInternalServerError)
				return
			}
			w.WriteHeader(http.StatusNoContent)
			return
		}
	}

	folders, _ := services.ListFolders(userID, 0)
	for _, folder := range folders {
		if folder.Name == filePath {
			if err := services.DeleteFolder(folder.ID, userID); err != nil {
				http.Error(w, err.Error(), http.StatusInternalServerError)
				return
			}
			w.WriteHeader(http.StatusNoContent)
			return
		}
	}

	http.Error(w, "Not found", http.StatusNotFound)
}

func (h *Handler) handleCopy(w http.ResponseWriter, r *http.Request, userID uint) {
	dest := r.Header.Get("Destination")
	if dest == "" {
		http.Error(w, "Destination header required", http.StatusBadRequest)
		return
	}

	http.Error(w, "Not implemented", http.StatusNotImplemented)
}

func (h *Handler) handleMove(w http.ResponseWriter, r *http.Request, userID uint) {
	dest := r.Header.Get("Destination")
	if dest == "" {
		http.Error(w, "Destination header required", http.StatusBadRequest)
		return
	}

	http.Error(w, "Not implemented", http.StatusNotImplemented)
}

func (h *Handler) handleLock(w http.ResponseWriter, r *http.Request, userID uint) {
	w.Header().Set("Lock-Token", "opaquelocktoken:cloudbw-lock-123")
	w.WriteHeader(http.StatusOK)
}

func (h *Handler) handleUnlock(w http.ResponseWriter, r *http.Request, userID uint) {
	w.WriteHeader(http.StatusNoContent)
}

func RegisterRoutes(r *http.ServeMux, authMiddleware func(http.Handler) http.Handler) {
	handler := NewHandler()
	r.Handle("/dav/", authMiddleware(http.StripPrefix("/dav", handler)))

	logger.Info("WebDAV routes registered")
}

type AuthMiddleware func(http.Handler) http.Handler

func BasicAuthMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		email, password, ok := r.BasicAuth()
		if !ok {
			w.Header().Set("WWW-Authenticate", `Basic realm="cloudBerrywing WebDAV"`)
			http.Error(w, "Unauthorized", http.StatusUnauthorized)
			return
		}

		_, user, err := services.AuthenticateUser(email, password)
		if err != nil {
			w.Header().Set("WWW-Authenticate", `Basic realm="cloudBerrywing WebDAV"`)
			http.Error(w, "Unauthorized", http.StatusUnauthorized)
			return
		}

		ctx := context.WithValue(r.Context(), "userID", user.ID)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}