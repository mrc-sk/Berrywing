package aria2

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"sync"
	"time"

	"github.com/cloudberrywing/cloudbw/pkg/logger"
)

type Client struct {
	endpoint string
	secret   string
	client   *http.Client
	mutex    sync.RWMutex
}

type Request struct {
	JSONRPC string        `json:"jsonrpc"`
	ID      string        `json:"id"`
	Method  string        `json:"method"`
	Params  []interface{} `json:"params"`
}

type Response struct {
	JSONRPC string          `json:"jsonrpc"`
	ID      string          `json:"id"`
	Result  json.RawMessage `json:"result,omitempty"`
	Error   *RPCError       `json:"error,omitempty"`
}

type RPCError struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

type TaskStatus string

const (
	TaskStatusActive   TaskStatus = "active"
	TaskStatusWaiting  TaskStatus = "waiting"
	TaskStatusPaused   TaskStatus = "paused"
	TaskStatusError    TaskStatus = "error"
	TaskStatusComplete TaskStatus = "complete"
)

type Task struct {
	GID           string                 `json:"gid"`
	Status        TaskStatus             `json:"status"`
	TotalLength   string                 `json:"totalLength"`
	CompletedLength string               `json:"completedLength"`
	UploadLength  string                 `json:"uploadLength"`
	Bitrate       string                 `json:"downloadSpeed"`
	UploadSpeed   string                 `json:"uploadSpeed"`
	InfoHash      string                 `json:"infoHash"`
	NumSeeders    string                 `json:"numSeeders"`
	Seeder        bool                   `json:"seeder"`
	PieceLength   string                 `json:"pieceLength"`
	NumPieces     string                 `json:"numPieces"`
	Connections   string                 `json:"connections"`
	ErrorMsg      string                 `json:"errorMessage"`
	ErrorCode     string                 `json:"errorCode"`
	Files         []FileInfo             `json:"files"`
	Dir           string                 `json:"dir"`
	Options       map[string]interface{} `json:"options"`
}

type FileInfo struct {
	Index       int    `json:"index"`
	Path        string `json:"path"`
	Length      string `json:"length"`
	CompletedLength string `json:"completedLength"`
	Selected    int    `json:"selected"`
}

func NewClient(endpoint, secret string) *Client {
	return &Client{
		endpoint: endpoint,
		secret:   secret,
		client: &http.Client{
			Timeout: 30 * time.Second,
		},
	}
}

func (c *Client) buildRequest(method string, params ...interface{}) Request {
	allParams := make([]interface{}, 0)
	if c.secret != "" {
		allParams = append(allParams, "token:"+c.secret)
	}
	allParams = append(allParams, params...)

	return Request{
		JSONRPC: "2.0",
		ID:      fmt.Sprintf("%d", time.Now().UnixNano()),
		Method:  method,
		Params:  allParams,
	}
}

func (c *Client) sendRequest(req Request) (*Response, error) {
	body, err := json.Marshal(req)
	if err != nil {
		return nil, err
	}

	httpReq, err := http.NewRequest("POST", c.endpoint, bytes.NewBuffer(body))
	if err != nil {
		return nil, err
	}
	httpReq.Header.Set("Content-Type", "application/json")

	resp, err := c.client.Do(httpReq)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	respBody, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}

	var response Response
	if err := json.Unmarshal(respBody, &response); err != nil {
		return nil, err
	}

	if response.Error != nil {
		return nil, fmt.Errorf("RPC error %d: %s", response.Error.Code, response.Error.Message)
	}

	return &response, nil
}

func (c *Client) AddURI(uri string, options ...map[string]interface{}) (string, error) {
	params := []interface{}{[]string{uri}}
	if len(options) > 0 {
		params = append(params, options[0])
	}

	req := c.buildRequest("aria2.addUri", params...)
	resp, err := c.sendRequest(req)
	if err != nil {
		return "", err
	}

	var gid string
	if err := json.Unmarshal(resp.Result, &gid); err != nil {
		return "", err
	}

	return gid, nil
}

func (c *Client) AddTorrent(torrentData []byte, options ...map[string]interface{}) (string, error) {
	base64Data := make([]byte, 0)
	params := []interface{}{base64Data}
	if len(options) > 0 {
		params = append(params, options[0])
	}

	req := c.buildRequest("aria2.addTorrent", params...)
	resp, err := c.sendRequest(req)
	if err != nil {
		return "", err
	}

	var gid string
	if err := json.Unmarshal(resp.Result, &gid); err != nil {
		return "", err
	}

	return gid, nil
}

func (c *Client) AddMetalink(metalinkData []byte, options ...map[string]interface{}) (string, error) {
	base64Data := make([]byte, 0)
	params := []interface{}{base64Data}
	if len(options) > 0 {
		params = append(params, options[0])
	}

	req := c.buildRequest("aria2.addMetalink", params...)
	resp, err := c.sendRequest(req)
	if err != nil {
		return "", err
	}

	var gid string
	if err := json.Unmarshal(resp.Result, &gid); err != nil {
		return "", err
	}

	return gid, nil
}

func (c *Client) Remove(gid string) error {
	req := c.buildRequest("aria2.remove", gid)
	_, err := c.sendRequest(req)
	return err
}

func (c *Client) ForceRemove(gid string) error {
	req := c.buildRequest("aria2.forceRemove", gid)
	_, err := c.sendRequest(req)
	return err
}

func (c *Client) Pause(gid string) error {
	req := c.buildRequest("aria2.pause", gid)
	_, err := c.sendRequest(req)
	return err
}

func (c *Client) PauseAll() error {
	req := c.buildRequest("aria2.pauseAll")
	_, err := c.sendRequest(req)
	return err
}

func (c *Client) ForcePause(gid string) error {
	req := c.buildRequest("aria2.forcePause", gid)
	_, err := c.sendRequest(req)
	return err
}

func (c *Client) ForcePauseAll() error {
	req := c.buildRequest("aria2.forcePauseAll")
	_, err := c.sendRequest(req)
	return err
}

func (c *Client) Unpause(gid string) error {
	req := c.buildRequest("aria2.unpause", gid)
	_, err := c.sendRequest(req)
	return err
}

func (c *Client) UnpauseAll() error {
	req := c.buildRequest("aria2.unpauseAll")
	_, err := c.sendRequest(req)
	return err
}

func (c *Client) TellStatus(gid string, keys ...string) (*Task, error) {
	params := []interface{}{gid}
	if len(keys) > 0 {
		params = append(params, keys)
	}

	req := c.buildRequest("aria2.tellStatus", params...)
	resp, err := c.sendRequest(req)
	if err != nil {
		return nil, err
	}

	var task Task
	if err := json.Unmarshal(resp.Result, &task); err != nil {
		return nil, err
	}

	return &task, nil
}

func (c *Client) TellActive() ([]Task, error) {
	req := c.buildRequest("aria2.tellActive")
	resp, err := c.sendRequest(req)
	if err != nil {
		return nil, err
	}

	var tasks []Task
	if err := json.Unmarshal(resp.Result, &tasks); err != nil {
		return nil, err
	}

	return tasks, nil
}

func (c *Client) TellWaiting(offset, num int) ([]Task, error) {
	req := c.buildRequest("aria2.tellWaiting", offset, num)
	resp, err := c.sendRequest(req)
	if err != nil {
		return nil, err
	}

	var tasks []Task
	if err := json.Unmarshal(resp.Result, &tasks); err != nil {
		return nil, err
	}

	return tasks, nil
}

func (c *Client) TellStopped(offset, num int) ([]Task, error) {
	req := c.buildRequest("aria2.tellStopped", offset, num)
	resp, err := c.sendRequest(req)
	if err != nil {
		return nil, err
	}

	var tasks []Task
	if err := json.Unmarshal(resp.Result, &tasks); err != nil {
		return nil, err
	}

	return tasks, nil
}

func (c *Client) GetGlobalStat() (map[string]interface{}, error) {
	req := c.buildRequest("aria2.getGlobalStat")
	resp, err := c.sendRequest(req)
	if err != nil {
		return nil, err
	}

	var stat map[string]interface{}
	if err := json.Unmarshal(resp.Result, &stat); err != nil {
		return nil, err
	}

	return stat, nil
}

func (c *Client) PurgeDownloadResult() error {
	req := c.buildRequest("aria2.purgeDownloadResult")
	_, err := c.sendRequest(req)
	return err
}

func (c *Client) RemoveDownloadResult(gid string) error {
	req := c.buildRequest("aria2.removeDownloadResult", gid)
	_, err := c.sendRequest(req)
	return err
}

func (c *Client) GetVersion() (map[string]interface{}, error) {
	req := c.buildRequest("aria2.getVersion")
	resp, err := c.sendRequest(req)
	if err != nil {
		return nil, err
	}

	var version map[string]interface{}
	if err := json.Unmarshal(resp.Result, &version); err != nil {
		return nil, err
	}

	return version, nil
}

func (c *Client) Shutdown() error {
	req := c.buildRequest("aria2.shutdown")
	_, err := c.sendRequest(req)
	return err
}

func (c *Client) ForceShutdown() error {
	req := c.buildRequest("aria2.forceShutdown")
	_, err := c.sendRequest(req)
	return err
}

func (c *Client) SetGlobalOption(options map[string]interface{}) error {
	req := c.buildRequest("aria2.changeGlobalOption", options)
	_, err := c.sendRequest(req)
	return err
}

func (c *Client) SetOption(gid string, options map[string]interface{}) error {
	req := c.buildRequest("aria2.changeOption", gid, options)
	_, err := c.sendRequest(req)
	return err
}

func (c *Client) GetOption(gid string) (map[string]interface{}, error) {
	req := c.buildRequest("aria2.getOption", gid)
	resp, err := c.sendRequest(req)
	if err != nil {
		return nil, err
	}

	var options map[string]interface{}
	if err := json.Unmarshal(resp.Result, &options); err != nil {
		return nil, err
	}

	return options, nil
}

func (c *Client) GetPeers(gid string) ([]map[string]interface{}, error) {
	req := c.buildRequest("aria2.getPeers", gid)
	resp, err := c.sendRequest(req)
	if err != nil {
		return nil, err
	}

	var peers []map[string]interface{}
	if err := json.Unmarshal(resp.Result, &peers); err != nil {
		return nil, err
	}

	return peers, nil
}

func (c *Client) GetServers(gid string) ([]map[string]interface{}, error) {
	req := c.buildRequest("aria2.getServers", gid)
	resp, err := c.sendRequest(req)
	if err != nil {
		return nil, err
	}

	var servers []map[string]interface{}
	if err := json.Unmarshal(resp.Result, &servers); err != nil {
		return nil, err
	}

	return servers, nil
}

func (c *Client) GetFiles(gid string) ([]FileInfo, error) {
	req := c.buildRequest("aria2.getFiles", gid)
	resp, err := c.sendRequest(req)
	if err != nil {
		return nil, err
	}

	var files []FileInfo
	if err := json.Unmarshal(resp.Result, &files); err != nil {
		return nil, err
	}

	return files, nil
}

type DownloadManager struct {
	client   *Client
	tasks    map[string]*Task
	listener chan *Task
	mutex    sync.RWMutex
}

func NewDownloadManager(endpoint, secret string) *DownloadManager {
	return &DownloadManager{
		client:   NewClient(endpoint, secret),
		tasks:    make(map[string]*Task),
		listener: make(chan *Task, 100),
	}
}

func (dm *DownloadManager) StartMonitor(interval time.Duration) {
	go func() {
		for {
			tasks, err := dm.client.TellActive()
			if err != nil {
				logger.Warn("Failed to fetch active tasks", logger.Error(err))
				time.Sleep(interval)
				continue
			}

			dm.mutex.Lock()
			for _, task := range tasks {
				dm.tasks[task.GID] = task
				select {
				case dm.listener <- task:
				default:
				}
			}
			dm.mutex.Unlock()

			time.Sleep(interval)
		}
	}()

	logger.Info("Download manager started")
}

func (dm *DownloadManager) AddDownload(uri string, options ...map[string]interface{}) (string, error) {
	gid, err := dm.client.AddURI(uri, options...)
	if err != nil {
		return "", err
	}

	dm.mutex.Lock()
	dm.tasks[gid] = &Task{GID: gid, Status: TaskStatusWaiting}
	dm.mutex.Unlock()

	return gid, nil
}

func (dm *DownloadManager) GetTask(gid string) (*Task, bool) {
	dm.mutex.RLock()
	task, exists := dm.tasks[gid]
	dm.mutex.RUnlock()
	return task, exists
}

func (dm *DownloadManager) RemoveTask(gid string) error {
	if err := dm.client.Remove(gid); err != nil {
		return err
	}

	dm.mutex.Lock()
	delete(dm.tasks, gid)
	dm.mutex.Unlock()

	return nil
}

func (dm *DownloadManager) ListTasks() []*Task {
	dm.mutex.RLock()
	tasks := make([]*Task, 0, len(dm.tasks))
	for _, task := range dm.tasks {
		tasks = append(tasks, task)
	}
	dm.mutex.RUnlock()
	return tasks
}

func (dm *DownloadManager) GetTaskListener() <-chan *Task {
	return dm.listener
}