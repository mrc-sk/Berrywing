package config

import (
	"github.com/spf13/viper"
)

var (
	Cfg *Config
)

type Config struct {
	Server   ServerConfig
	Database DatabaseConfig
	Storage  StorageConfig
	Security SecurityConfig
	Aria2    Aria2Config
	Plugin   PluginConfig
}

type ServerConfig struct {
	Host string
	Port int
	Mode string
}

type DatabaseConfig struct {
	Type     string
	Path     string
	Host     string
	Port     int
	User     string
	Password string
	Name     string
}

type StorageConfig struct {
	Provider string
	Path     string
	S3Config S3Config
}

type S3Config struct {
	Endpoint        string
	AccessKeyID     string
	SecretAccessKey string
	Bucket          string
	Region          string
}

type SecurityConfig struct {
	MasterKey string
	JWTSecret string
}

type Aria2Config struct {
	Enabled  bool
	Endpoint string
	Secret   string
}

type PluginConfig struct {
	Enabled bool
	Dir     string
}

func LoadConfig(path string) error {
	viper.SetConfigFile(path)
	viper.SetConfigType("toml")

	viper.SetDefault("server.host", "0.0.0.0")
	viper.SetDefault("server.port", 8080)
	viper.SetDefault("server.mode", "debug")
	viper.SetDefault("database.type", "sqlite")
	viper.SetDefault("database.path", "./data/cloudbw.db")
	viper.SetDefault("storage.provider", "local")
	viper.SetDefault("storage.path", "./storage")
	viper.SetDefault("aria2.enabled", false)
	viper.SetDefault("aria2.endpoint", "http://localhost:6800/jsonrpc")
	viper.SetDefault("aria2.secret", "")
	viper.SetDefault("plugin.enabled", false)
	viper.SetDefault("plugin.dir", "./plugins")

	if err := viper.ReadInConfig(); err != nil {
		if _, ok := err.(viper.ConfigFileNotFoundError); ok {
			return nil
		}
		return err
	}

	Cfg = &Config{}
	return viper.Unmarshal(Cfg)
}