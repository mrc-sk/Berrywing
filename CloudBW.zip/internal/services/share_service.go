package services

import (
	"crypto/rand"
	"encoding/hex"
	"errors"
	"time"

	"github.com/cloudberrywing/cloudbw/internal/models"
)

func GetShareByToken(token string) (*models.Share, error) {
	var share models.Share
	if err := DB.Where("token = ?", token).First(&share).Error; err != nil {
		return nil, err
	}

	if share.ExpiresAt != nil && share.ExpiresAt.Before(time.Now()) {
		return nil, errors.New("share link has expired")
	}

	share.Views++
	DB.Save(&share)

	return &share, nil
}

func CreateShare(userID, fileID, folderID uint, password string, expiresIn int) (*models.Share, error) {
	token, err := generateShareToken()
	if err != nil {
		return nil, err
	}

	share := &models.Share{
		Token:     token,
		CreatorID: userID,
		FileID:    &fileID,
		FolderID:  &folderID,
		Password:  password,
		IsPublic:  password == "",
	}

	if expiresIn > 0 {
		expiresAt := time.Now().Add(time.Duration(expiresIn) * time.Hour)
		share.ExpiresAt = &expiresAt
	}

	if err := DB.Create(share).Error; err != nil {
		return nil, err
	}

	return share, nil
}

func DeleteShare(id, userID uint) error {
	var share models.Share
	if err := DB.Where("id = ? AND creator_id = ?", id, userID).First(&share).Error; err != nil {
		return err
	}

	return DB.Delete(&share).Error
}

func generateShareToken() (string, error) {
	bytes := make([]byte, 16)
	if _, err := rand.Read(bytes); err != nil {
		return "", err
	}
	return hex.EncodeToString(bytes), nil
}