package services

import (
	"github.com/cloudberrywing/cloudbw/internal/models"
)

type StorageInfo struct {
	Used     int64 `json:"used"`
	Available int64 `json:"available"`
	Max       int64 `json:"max"`
}

func GetStorageInfo(userID uint) (*StorageInfo, error) {
	var user models.User
	if err := DB.First(&user, userID).Error; err != nil {
		return nil, err
	}

	var totalSize int64
	DB.Model(&models.File{}).Where("owner_id = ?", userID).Select("COALESCE(SUM(size), 0)").Scan(&totalSize)

	return &StorageInfo{
		Used:      totalSize,
		Available: user.MaxStorage - totalSize,
		Max:       user.MaxStorage,
	}, nil
}

func ListStoragePolicies() ([]models.StoragePolicy, error) {
	var policies []models.StoragePolicy
	if err := DB.Where("enabled = ?", true).Find(&policies).Error; err != nil {
		return nil, err
	}
	return policies, nil
}

func CreateStoragePolicy(name, ptype, config string, isDefault bool) (*models.StoragePolicy, error) {
	if isDefault {
		DB.Model(&models.StoragePolicy{}).Where("is_default = ?", true).Update("is_default", false)
	}

	policy := &models.StoragePolicy{
		Name:      name,
		Type:      ptype,
		Config:    config,
		IsDefault: isDefault,
		MaxSize:   10737418240,
		Enabled:   true,
	}

	if err := DB.Create(policy).Error; err != nil {
		return nil, err
	}

	return policy, nil
}