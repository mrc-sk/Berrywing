package services

import (
	"errors"
	"time"

	"github.com/cloudberrywing/cloudbw/internal/models"
	"github.com/cloudberrywing/cloudbw/pkg/logger"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

var DB *gorm.DB

func InitDatabase(dsn string) error {
	var err error
	DB, err = gorm.Open(sqlite.Open(dsn), &gorm.Config{})
	if err != nil {
		return err
	}

	err = DB.AutoMigrate(
		&models.User{},
		&models.UserGroup{},
		&models.File{},
		&models.Folder{},
		&models.StoragePolicy{},
		&models.Share{},
		&models.Task{},
	)
	if err != nil {
		return err
	}

	if err := createDefaultPolicy(); err != nil {
		return err
	}

	if err := createDefaultAdmin(); err != nil {
		return err
	}

	logger.Info("Database initialized successfully")
	return nil
}

func createDefaultPolicy() error {
	var count int64
	DB.Model(&models.StoragePolicy{}).Count(&count)
	if count == 0 {
		policy := models.StoragePolicy{
			Name:      "Local Storage",
			Type:      "local",
			Config:    "{}",
			IsDefault: true,
			MaxSize:   10737418240,
			Enabled:   true,
		}
		return DB.Create(&policy).Error
	}
	return nil
}

func createDefaultAdmin() error {
	var count int64
	DB.Model(&models.User{}).Count(&count)
	if count == 0 {
		hashedPassword, _ := bcrypt.GenerateFromPassword([]byte("admin123"), bcrypt.DefaultCost)
		admin := models.User{
			Email:     "admin@cloudbw.local",
			Password:  string(hashedPassword),
			Nickname:  "Administrator",
			MaxStorage: 107374182400,
			Status:    1,
		}
		return DB.Create(&admin).Error
	}
	return nil
}

func CreateUser(email, password, nickname string) (*models.User, error) {
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return nil, err
	}

	user := &models.User{
		Email:     email,
		Password:  string(hashedPassword),
		Nickname:  nickname,
		MaxStorage: 10737418240,
		Status:    1,
	}

	if err := DB.Create(user).Error; err != nil {
		return nil, err
	}

	return user, nil
}

func AuthenticateUser(email, password string) (string, *models.User, error) {
	var user models.User
	if err := DB.Where("email = ?", email).First(&user).Error; err != nil {
		return "", nil, errors.New("user not found")
	}

	if err := bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(password)); err != nil {
		return "", nil, errors.New("invalid password")
	}

	token := generateToken(user.ID)
	return token, &user, nil
}

func generateToken(userID uint) string {
	return time.Now().Format("20060102150405") + "_token_" + string(rune(userID))
}

func GetUser(id uint) (*models.User, error) {
	var user models.User
	if err := DB.First(&user, id).Error; err != nil {
		return nil, err
	}
	return &user, nil
}

func UpdateUser(id uint, nickname string) (*models.User, error) {
	var user models.User
	if err := DB.First(&user, id).Error; err != nil {
		return nil, err
	}

	user.Nickname = nickname
	if err := DB.Save(&user).Error; err != nil {
		return nil, err
	}

	return &user, nil
}

func GetUserSettings(userID uint) (map[string]interface{}, error) {
	return map[string]interface{}{
		"theme":      "light",
		"language":   "zh-CN",
		"view_mode":   "list",
		"sort_by":     "name",
		"sort_order":  "asc",
	}, nil
}

func UpdateUserSettings(userID uint, settings map[string]interface{}) error {
	return nil
}