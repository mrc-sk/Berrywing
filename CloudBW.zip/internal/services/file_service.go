package services

import (
	"io"
	"mime/multipart"
	"os"
	"path/filepath"
	"time"

	"github.com/cloudberrywing/cloudbw/internal/models"
	"github.com/cloudberrywing/cloudbw/pkg/logger"
)

func ListFiles(userID, parentID uint) ([]models.File, error) {
	var files []models.File
	query := DB.Where("owner_id = ?", userID)
	if parentID > 0 {
		query = query.Where("parent_id = ?", parentID)
	} else {
		query = query.Where("parent_id IS NULL")
	}

	if err := query.Find(&files).Error; err != nil {
		return nil, err
	}
	return files, nil
}

func GetFile(id uint) (*models.File, error) {
	var file models.File
	if err := DB.First(&file, id).Error; err != nil {
		return nil, err
	}
	return &file, nil
}

func UploadFile(userID, parentID uint, fileHeader *multipart.FileHeader) (*models.File, error) {
	src, err := fileHeader.Open()
	if err != nil {
		return nil, err
	}
	defer src.Close()

	storagePath := "./storage/" + time.Now().Format("2006/01/02")
	if err := os.MkdirAll(storagePath, 0755); err != nil {
		return nil, err
	}

	ext := filepath.Ext(fileHeader.Filename)
	filename := generateFileName() + ext
	dstPath := filepath.Join(storagePath, filename)

	dst, err := os.Create(dstPath)
	if err != nil {
		return nil, err
	}
	defer dst.Close()

	if _, err := io.Copy(dst, src); err != nil {
		return nil, err
	}

	file := &models.File{
		Name:       fileHeader.Filename,
		Size:       fileHeader.Size,
		Path:       dstPath,
		ParentID:   &parentID,
		OwnerID:    userID,
		MimeType:   fileHeader.Header.Get("Content-Type"),
		Extension:  ext,
		UploadedAt: time.Now(),
	}

	if err := DB.Create(file).Error; err != nil {
		os.Remove(dstPath)
		return nil, err
	}

	logger.Info("File uploaded",
		logger.String("filename", fileHeader.Filename),
		logger.Int64("size", fileHeader.Size),
	)

	return file, nil
}

func DeleteFile(id, userID uint) error {
	var file models.File
	if err := DB.Where("id = ? AND owner_id = ?", id, userID).First(&file).Error; err != nil {
		return err
	}

	if err := os.Remove(file.Path); err != nil {
		logger.Warn("Failed to delete physical file", logger.String("path", file.Path))
	}

	return DB.Delete(&file).Error
}

func UpdateFile(id, userID uint, name string) (*models.File, error) {
	var file models.File
	if err := DB.Where("id = ? AND owner_id = ?", id, userID).First(&file).Error; err != nil {
		return nil, err
	}

	file.Name = name
	if err := DB.Save(&file).Error; err != nil {
		return nil, err
	}

	return &file, nil
}

func ListFolders(userID, parentID uint) ([]models.Folder, error) {
	var folders []models.Folder
	query := DB.Where("owner_id = ?", userID)
	if parentID > 0 {
		query = query.Where("parent_id = ?", parentID)
	} else {
		query = query.Where("parent_id IS NULL")
	}

	if err := query.Find(&folders).Error; err != nil {
		return nil, err
	}
	return folders, nil
}

func GetFolder(id uint) (*models.Folder, error) {
	var folder models.Folder
	if err := DB.First(&folder, id).Error; err != nil {
		return nil, err
	}
	return &folder, nil
}

func CreateFolder(userID, parentID uint, name string) (*models.Folder, error) {
	folder := &models.Folder{
		Name:     name,
		ParentID: &parentID,
		OwnerID:  userID,
		Path:     "/" + name,
	}

	if err := DB.Create(folder).Error; err != nil {
		return nil, err
	}

	return folder, nil
}

func UpdateFolder(id, userID uint, name string) (*models.Folder, error) {
	var folder models.Folder
	if err := DB.Where("id = ? AND owner_id = ?", id, userID).First(&folder).Error; err != nil {
		return nil, err
	}

	folder.Name = name
	if err := DB.Save(&folder).Error; err != nil {
		return nil, err
	}

	return &folder, nil
}

func DeleteFolder(id, userID uint) error {
	var folder models.Folder
	if err := DB.Where("id = ? AND owner_id = ?", id, userID).First(&folder).Error; err != nil {
		return err
	}

	return DB.Delete(&folder).Error
}

func generateFileName() string {
	return time.Now().Format("20060102150405") + "_" + randomString(8)
}

func randomString(length int) string {
	const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	result := make([]byte, length)
	for i := range result {
		result[i] = chars[time.Now().UnixNano()%int64(len(chars))]
	}
	return string(result)
}