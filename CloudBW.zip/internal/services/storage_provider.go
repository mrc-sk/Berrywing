package services

import (
	"context"
	"fmt"
	"io"
	"os"
	"path/filepath"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/credentials"
	"github.com/aws/aws-sdk-go-v2/service/s3"
	"github.com/cloudberrywing/cloudbw/internal/config"
	"github.com/cloudberrywing/cloudbw/pkg/logger"
)

type Storage interface {
	Upload(ctx context.Context, key string, reader io.Reader, size int64) error
	Download(ctx context.Context, key string, writer io.Writer) error
	Delete(ctx context.Context, key string) error
	GetURL(ctx context.Context, key string) (string, error)
}

type LocalStorage struct {
	basePath string
}

func NewLocalStorage(basePath string) *LocalStorage {
	os.MkdirAll(basePath, 0755)
	return &LocalStorage{basePath: basePath}
}

func (l *LocalStorage) Upload(ctx context.Context, key string, reader io.Reader, size int64) error {
	path := filepath.Join(l.basePath, key)
	dir := filepath.Dir(path)
	if err := os.MkdirAll(dir, 0755); err != nil {
		return err
	}

	file, err := os.Create(path)
	if err != nil {
		return err
	}
	defer file.Close()

	_, err = io.Copy(file, reader)
	return err
}

func (l *LocalStorage) Download(ctx context.Context, key string, writer io.Writer) error {
	path := filepath.Join(l.basePath, key)
	file, err := os.Open(path)
	if err != nil {
		return err
	}
	defer file.Close()

	_, err = io.Copy(writer, file)
	return err
}

func (l *LocalStorage) Delete(ctx context.Context, key string) error {
	path := filepath.Join(l.basePath, key)
	return os.Remove(path)
}

func (l *LocalStorage) GetURL(ctx context.Context, key string) (string, error) {
	return "/storage/" + key, nil
}

type S3Storage struct {
	client   *s3.Client
	bucket  string
	endpoint string
}

func NewS3Storage(endpoint, accessKey, secretKey, bucket, region string) (*S3Storage, error) {
	creds := credentials.NewStaticCredentialsProvider(accessKey, secretKey, "")

	cfg, err := config.LoadDefaultConfig(context.Background(),
		config.WithRegion(region),
		config.WithCredentialsProvider(creds),
	)
	if err != nil {
		return nil, err
	}

	client := s3.NewFromConfig(cfg, func(o *s3.Options) {
		o.BaseEndpoint = aws.String(endpoint)
		o.UsePathStyle = true
	})

	return &S3Storage{
		client:   client,
		bucket:   bucket,
		endpoint: endpoint,
	}, nil
}

func (s *S3Storage) Upload(ctx context.Context, key string, reader io.Reader, size int64) error {
	_, err := s.client.PutObject(ctx, &s3.PutObjectInput{
		Bucket: aws.String(s.bucket),
		Key:    aws.String(key),
		Body:   reader,
	})
	return err
}

func (s *S3Storage) Download(ctx context.Context, key string, writer io.Writer) error {
	result, err := s.client.GetObject(ctx, &s3.GetObjectInput{
		Bucket: aws.String(s.bucket),
		Key:    aws.String(key),
	})
	if err != nil {
		return err
	}
	defer result.Body.Close()

	_, err = io.Copy(writer, result.Body)
	return err
}

func (s *S3Storage) Delete(ctx context.Context, key string) error {
	_, err := s.client.DeleteObject(ctx, &s3.DeleteObjectInput{
		Bucket: aws.String(s.bucket),
		Key:    aws.String(key),
	})
	return err
}

func (s *S3Storage) GetURL(ctx context.Context, key string) (string, error) {
	return fmt.Sprintf("%s/%s/%s", s.endpoint, s.bucket, key), nil
}

func GetStorageProvider() Storage {
	provider := config.Cfg.Storage.Provider
	switch provider {
	case "s3":
		s3Cfg := config.Cfg.Storage.S3Config
		storage, err := NewS3Storage(
			s3Cfg.Endpoint,
			s3Cfg.AccessKeyID,
			s3Cfg.SecretAccessKey,
			s3Cfg.Bucket,
			s3Cfg.Region,
		)
		if err != nil {
			logger.Error("Failed to create S3 storage", logger.Error(err))
			return NewLocalStorage(config.Cfg.Storage.Path)
		}
		return storage
	default:
		return NewLocalStorage(config.Cfg.Storage.Path)
	}
}