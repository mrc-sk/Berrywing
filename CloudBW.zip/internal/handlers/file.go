package handlers

import (
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"github.com/cloudberrywing/cloudbw/internal/services"
	"github.com/cloudberrywing/cloudbw/pkg/response"
)

func ListFiles(c *gin.Context) {
	folderID := c.Query("folder_id")
	parentID := uint(0)
	if folderID != "" {
		var err error
		parentID, err = strconv.ParseUint(folderID, 10, 32)
		if err != nil {
			response.Error(c, http.StatusBadRequest, "Invalid folder ID")
			return
		}
	}

	userID := c.GetUint("userID")
	files, err := services.ListFiles(userID, uint(parentID))
	if err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, files)
}

func UploadFile(c *gin.Context) {
	userID := c.GetUint("userID")

	file, err := c.FormFile("file")
	if err != nil {
		response.Error(c, http.StatusBadRequest, "No file uploaded")
		return
	}

	parentIDStr := c.PostForm("folder_id")
	var parentID uint
	if parentIDStr != "" {
		var err error
		parentID, err = strconv.ParseUint(parentIDStr, 10, 32)
		if err != nil {
			response.Error(c, http.StatusBadRequest, "Invalid folder ID")
			return
		}
	}

	uploadedFile, err := services.UploadFile(userID, parentID, file)
	if err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, uploadedFile)
}

func DownloadFile(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.ParseUint(idStr, 10, 32)
	if err != nil {
		response.Error(c, http.StatusBadRequest, "Invalid file ID")
		return
	}

	file, err := services.GetFile(uint(id))
	if err != nil {
		response.Error(c, http.StatusNotFound, "File not found")
		return
	}

	c.File(file.Path)
}

func DeleteFile(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.ParseUint(idStr, 10, 32)
	if err != nil {
		response.Error(c, http.StatusBadRequest, "Invalid file ID")
		return
	}

	userID := c.GetUint("userID")
	if err := services.DeleteFile(uint(id), userID); err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, gin.H{"message": "File deleted successfully"})
}

func GetFileInfo(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.ParseUint(idStr, 10, 32)
	if err != nil {
		response.Error(c, http.StatusBadRequest, "Invalid file ID")
		return
	}

	file, err := services.GetFile(uint(id))
	if err != nil {
		response.Error(c, http.StatusNotFound, "File not found")
		return
	}

	response.Success(c, file)
}

func UpdateFile(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.ParseUint(idStr, 10, 32)
	if err != nil {
		response.Error(c, http.StatusBadRequest, "Invalid file ID")
		return
	}

	var req struct {
		Name string `json:"name"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, http.StatusBadRequest, "Invalid request")
		return
	}

	userID := c.GetUint("userID")
	file, err := services.UpdateFile(uint(id), userID, req.Name)
	if err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, file)
}