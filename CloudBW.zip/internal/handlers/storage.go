package handlers

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/cloudberrywing/cloudbw/internal/services"
	"github.com/cloudberrywing/cloudbw/pkg/response"
)

func GetStorageInfo(c *gin.Context) {
	userID := c.GetUint("userID")

	info, err := services.GetStorageInfo(userID)
	if err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, info)
}

func ListStoragePolicies(c *gin.Context) {
	policies, err := services.ListStoragePolicies()
	if err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, policies)
}

func CreateStoragePolicy(c *gin.Context) {
	var req struct {
		Name     string `json:"name" binding:"required"`
		Type     string `json:"type" binding:"required"`
		Config   string `json:"config"`
		IsDefault bool  `json:"is_default"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, http.StatusBadRequest, "Invalid request")
		return
	}

	policy, err := services.CreateStoragePolicy(req.Name, req.Type, req.Config, req.IsDefault)
	if err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, policy)
}