package handlers

import (
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"github.com/cloudberrywing/cloudbw/internal/router"
	"github.com/cloudberrywing/cloudbw/pkg/response"
)

func AddDownload(c *gin.Context) {
	var req struct {
		URI     string                 `json:"uri" binding:"required"`
		Options map[string]interface{} `json:"options"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, http.StatusBadRequest, "Invalid request")
		return
	}

	dm := router.GetDownloadManager()
	if dm == nil {
		response.Error(c, http.StatusServiceUnavailable, "Download manager not available")
		return
	}

	gid, err := dm.AddDownload(req.URI, req.Options)
	if err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, gin.H{"gid": gid})
}

func ListDownloads(c *gin.Context) {
	dm := router.GetDownloadManager()
	if dm == nil {
		response.Error(c, http.StatusServiceUnavailable, "Download manager not available")
		return
	}

	tasks := dm.ListTasks()
	response.Success(c, tasks)
}

func GetDownload(c *gin.Context) {
	gid := c.Param("gid")

	dm := router.GetDownloadManager()
	if dm == nil {
		response.Error(c, http.StatusServiceUnavailable, "Download manager not available")
		return
	}

	task, exists := dm.GetTask(gid)
	if !exists {
		response.Error(c, http.StatusNotFound, "Download task not found")
		return
	}

	response.Success(c, task)
}

func RemoveDownload(c *gin.Context) {
	gid := c.Param("gid")

	dm := router.GetDownloadManager()
	if dm == nil {
		response.Error(c, http.StatusServiceUnavailable, "Download manager not available")
		return
	}

	if err := dm.RemoveTask(gid); err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, gin.H{"message": "Download removed"})
}

func PauseDownload(c *gin.Context) {
	gid := c.Param("gid")

	dm := router.GetDownloadManager()
	if dm == nil {
		response.Error(c, http.StatusServiceUnavailable, "Download manager not available")
		return
	}

	if err := dm.client.Pause(gid); err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, gin.H{"message": "Download paused"})
}

func ResumeDownload(c *gin.Context) {
	gid := c.Param("gid")

	dm := router.GetDownloadManager()
	if dm == nil {
		response.Error(c, http.StatusServiceUnavailable, "Download manager not available")
		return
	}

	if err := dm.client.Unpause(gid); err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, gin.H{"message": "Download resumed"})
}