package handlers

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/cloudberrywing/cloudbw/internal/plugin"
	"github.com/cloudberrywing/cloudbw/pkg/response"
)

func ListComponents(c *gin.Context) {
	lm := plugin.GetLayoutManager()
	components := lm.ListComponents()
	response.Success(c, components)
}

func GetComponentSchema(c *gin.Context) {
	id := c.Param("id")

	lm := plugin.GetLayoutManager()
	schema, exists := lm.GetComponentSchema(id)
	if !exists {
		response.Error(c, http.StatusNotFound, "Component not found")
		return
	}

	response.Success(c, schema)
}

func ListPages(c *gin.Context) {
	lm := plugin.GetLayoutManager()
	pages := make([]*plugin.PageLayout, 0)
	for _, page := range lm.pages {
		pages = append(pages, page)
	}
	response.Success(c, pages)
}

func GetPage(c *gin.Context) {
	id := c.Param("id")

	lm := plugin.GetLayoutManager()
	page, exists := lm.GetPage(id)
	if !exists {
		response.Error(c, http.StatusNotFound, "Page not found")
		return
	}

	response.Success(c, page)
}

func CreatePage(c *gin.Context) {
	var layout plugin.PageLayout
	if err := c.ShouldBindJSON(&layout); err != nil {
		response.Error(c, http.StatusBadRequest, "Invalid request")
		return
	}

	lm := plugin.GetLayoutManager()
	if err := lm.CreatePage(layout); err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, layout)
}

func UpdatePage(c *gin.Context) {
	id := c.Param("id")

	var layout plugin.PageLayout
	if err := c.ShouldBindJSON(&layout); err != nil {
		response.Error(c, http.StatusBadRequest, "Invalid request")
		return
	}

	layout.ID = id

	lm := plugin.GetLayoutManager()
	if err := lm.UpdatePage(layout); err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, layout)
}

func DeletePage(c *gin.Context) {
	id := c.Param("id")

	lm := plugin.GetLayoutManager()
	if err := lm.DeletePage(id); err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, gin.H{"message": "Page deleted"})
}

func RenderPage(c *gin.Context) {
	id := c.Param("id")

	lm := plugin.GetLayoutManager()
	content, err := lm.RenderPage(c.Request.Context(), id)
	if err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, gin.H{"content": content})
}

func PreviewFile(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.ParseUint(idStr, 10, 32)
	if err != nil {
		response.Error(c, http.StatusBadRequest, "Invalid file ID")
		return
	}

	file, err := services.GetFile(uint(id))
	if err != nil {
		response.Error(c, http.StatusNotFound, "File not found")
		return
	}

	c.File(file.Path)
}