package handlers

import (
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"github.com/cloudberrywing/cloudbw/internal/services"
	"github.com/cloudberrywing/cloudbw/pkg/response"
)

func ListFolders(c *gin.Context) {
	folderID := c.Query("folder_id")
	parentID := uint(0)
	if folderID != "" {
		var err error
		parentID, err = strconv.ParseUint(folderID, 10, 32)
		if err != nil {
			response.Error(c, http.StatusBadRequest, "Invalid folder ID")
			return
		}
	}

	userID := c.GetUint("userID")
	folders, err := services.ListFolders(userID, parentID)
	if err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, folders)
}

func CreateFolder(c *gin.Context) {
	var req struct {
		Name     string `json:"name" binding:"required"`
		ParentID uint   `json:"parent_id"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, http.StatusBadRequest, "Invalid request")
		return
	}

	userID := c.GetUint("userID")
	folder, err := services.CreateFolder(userID, req.ParentID, req.Name)
	if err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, folder)
}

func GetFolderInfo(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.ParseUint(idStr, 10, 32)
	if err != nil {
		response.Error(c, http.StatusBadRequest, "Invalid folder ID")
		return
	}

	folder, err := services.GetFolder(uint(id))
	if err != nil {
		response.Error(c, http.StatusNotFound, "Folder not found")
		return
	}

	response.Success(c, folder)
}

func UpdateFolder(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.ParseUint(idStr, 10, 32)
	if err != nil {
		response.Error(c, http.StatusBadRequest, "Invalid folder ID")
		return
	}

	var req struct {
		Name string `json:"name"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, http.StatusBadRequest, "Invalid request")
		return
	}

	userID := c.GetUint("userID")
	folder, err := services.UpdateFolder(uint(id), userID, req.Name)
	if err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, folder)
}

func DeleteFolder(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.ParseUint(idStr, 10, 32)
	if err != nil {
		response.Error(c, http.StatusBadRequest, "Invalid folder ID")
		return
	}

	userID := c.GetUint("userID")
	if err := services.DeleteFolder(uint(id), userID); err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, gin.H{"message": "Folder deleted successfully"})
}