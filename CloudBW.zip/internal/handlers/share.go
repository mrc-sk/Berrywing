package handlers

import (
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"github.com/cloudberrywing/cloudbw/internal/services"
	"github.com/cloudberrywing/cloudbw/pkg/response"
)

func GetShare(c *gin.Context) {
	token := c.Param("token")

	share, err := services.GetShareByToken(token)
	if err != nil {
		response.Error(c, http.StatusNotFound, "Share not found")
		return
	}

	response.Success(c, share)
}

func CreateShare(c *gin.Context) {
	var req struct {
		FileID    uint   `json:"file_id"`
		FolderID  uint   `json:"folder_id"`
		Password  string `json:"password"`
		ExpiresIn int    `json:"expires_in"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, http.StatusBadRequest, "Invalid request")
		return
	}

	userID := c.GetUint("userID")
	share, err := services.CreateShare(userID, req.FileID, req.FolderID, req.Password, req.ExpiresIn)
	if err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, share)
}

func DeleteShare(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.ParseUint(idStr, 10, 32)
	if err != nil {
		response.Error(c, http.StatusBadRequest, "Invalid share ID")
		return
	}

	userID := c.GetUint("userID")
	if err := services.DeleteShare(uint(id), userID); err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, gin.H{"message": "Share deleted successfully"})
}