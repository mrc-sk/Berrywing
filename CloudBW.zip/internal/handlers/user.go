package handlers

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/cloudberrywing/cloudbw/internal/services"
	"github.com/cloudberrywing/cloudbw/pkg/response"
)

func GetUserInfo(c *gin.Context) {
	userID := c.GetUint("userID")

	user, err := services.GetUser(userID)
	if err != nil {
		response.Error(c, http.StatusNotFound, "User not found")
		return
	}

	response.Success(c, user)
}

func UpdateUserInfo(c *gin.Context) {
	var req struct {
		Nickname string `json:"nickname"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, http.StatusBadRequest, "Invalid request")
		return
	}

	userID := c.GetUint("userID")
	user, err := services.UpdateUser(userID, req.Nickname)
	if err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, user)
}

func GetUserSettings(c *gin.Context) {
	userID := c.GetUint("userID")

	settings, err := services.GetUserSettings(userID)
	if err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, settings)
}

func UpdateUserSettings(c *gin.Context) {
	var req map[string]interface{}

	if err := c.ShouldBindJSON(&req); err != nil {
		response.Error(c, http.StatusBadRequest, "Invalid request")
		return
	}

	userID := c.GetUint("userID")
	if err := services.UpdateUserSettings(userID, req); err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, gin.H{"message": "Settings updated successfully"})
}