package handlers

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/cloudberrywing/cloudbw/internal/plugin"
	"github.com/cloudberrywing/cloudbw/pkg/response"
)

func ListPlugins(c *gin.Context) {
	pm := plugin.GetPluginManager()
	plugins := pm.ListPlugins()

	result := make([]map[string]interface{}, 0, len(plugins))
	for _, p := range plugins {
		result = append(result, map[string]interface{}{
			"name":        p.Name(),
			"version":     p.Version(),
			"description": p.Description(),
		})
	}

	response.Success(c, result)
}

func GetPlugin(c *gin.Context) {
	name := c.Param("name")

	pm := plugin.GetPluginManager()
	info := pm.GetPluginInfo(name)
	if info == nil {
		response.Error(c, http.StatusNotFound, "Plugin not found")
		return
	}

	response.Success(c, info)
}

func EnablePlugin(c *gin.Context) {
	name := c.Param("name")

	pm := plugin.GetPluginManager()
	if err := pm.EnablePlugin(name); err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, gin.H{"message": "Plugin enabled"})
}

func DisablePlugin(c *gin.Context) {
	name := c.Param("name")

	pm := plugin.GetPluginManager()
	if err := pm.DisablePlugin(name); err != nil {
		response.Error(c, http.StatusInternalServerError, err.Error())
		return
	}

	response.Success(c, gin.H{"message": "Plugin disabled"})
}

func ReloadPlugins(c *gin.Context) {
	pm := plugin.GetPluginManager()
	for _, p := range pm.ListPlugins() {
		pm.UnloadPlugin(p.Name())
	}

	response.Success(c, gin.H{"message": "Plugins reloaded"})
}