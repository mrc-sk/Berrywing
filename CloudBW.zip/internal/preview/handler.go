package preview

import (
	"encoding/json"
	"fmt"
	"image"
	"image/jpeg"
	"image/png"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"

	"github.com/cloudberrywing/cloudbw/internal/models"
	"github.com/cloudberrywing/cloudbw/internal/services"
	"github.com/cloudberrywing/cloudbw/pkg/logger"
)

type Handler struct{}

func NewHandler() *Handler {
	return &Handler{}
}

func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	path := r.URL.Path
	if path == "/" {
		http.Error(w, "Not found", http.StatusNotFound)
		return
	}

	fileID := strings.TrimPrefix(path, "/")

	file, err := services.GetFileByID(fileID)
	if err != nil {
		http.Error(w, "File not found", http.StatusNotFound)
		return
	}

	h.servePreview(w, r, file)
}

func (h *Handler) servePreview(w http.ResponseWriter, r *http.Request, file *models.File) {
	switch h.getPreviewType(file.MimeType) {
	case "image":
		h.serveImagePreview(w, file)
	case "pdf":
		h.servePDFPreview(w, file)
	case "video":
		h.serveVideoPreview(w, file)
	case "audio":
		h.serveAudioPreview(w, file)
	case "text":
		h.serveTextPreview(w, file)
	case "code":
		h.serveCodePreview(w, file)
	default:
		h.serveDefaultPreview(w, file)
	}
}

func (h *Handler) getPreviewType(mimeType string) string {
	switch {
	case strings.HasPrefix(mimeType, "image/"):
		return "image"
	case mimeType == "application/pdf":
		return "pdf"
	case strings.HasPrefix(mimeType, "video/"):
		return "video"
	case strings.HasPrefix(mimeType, "audio/"):
		return "audio"
	case strings.HasPrefix(mimeType, "text/"):
		return "text"
	case strings.HasSuffix(mimeType, "javascript") || 
		 strings.HasSuffix(mimeType, "json") || 
		 strings.HasSuffix(mimeType, "xml") ||
		 strings.HasSuffix(mimeType, "html") ||
		 strings.HasSuffix(mimeType, "css"):
		return "code"
	default:
		return "default"
	}
}

func (h *Handler) serveImagePreview(w http.ResponseWriter, file *models.File) {
	f, err := os.Open(file.Path)
	if err != nil {
		http.Error(w, "Failed to open file", http.StatusInternalServerError)
		return
	}
	defer f.Close()

	w.Header().Set("Content-Type", file.MimeType)

	switch file.Extension {
	case ".jpg", ".jpeg":
		img, err := jpeg.Decode(f)
		if err != nil {
			http.Error(w, "Failed to decode image", http.StatusInternalServerError)
			return
		}
		jpeg.Encode(w, img, nil)
	case ".png":
		img, err := png.Decode(f)
		if err != nil {
			http.Error(w, "Failed to decode image", http.StatusInternalServerError)
			return
		}
		png.Encode(w, img)
	default:
		io.Copy(w, f)
	}
}

func (h *Handler) servePDFPreview(w http.ResponseWriter, file *models.File) {
	f, err := os.Open(file.Path)
	if err != nil {
		http.Error(w, "Failed to open file", http.StatusInternalServerError)
		return
	}
	defer f.Close()

	w.Header().Set("Content-Type", "application/pdf")
	w.Header().Set("Content-Disposition", fmt.Sprintf("inline; filename=%s", file.Name))
	io.Copy(w, f)
}

func (h *Handler) serveVideoPreview(w http.ResponseWriter, file *models.File) {
	f, err := os.Open(file.Path)
	if err != nil {
		http.Error(w, "Failed to open file", http.StatusInternalServerError)
		return
	}
	defer f.Close()

	fi, err := f.Stat()
	if err != nil {
		http.Error(w, "Failed to get file info", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", file.MimeType)
	w.Header().Set("Content-Length", fmt.Sprintf("%d", fi.Size()))
	w.Header().Set("Accept-Ranges", "bytes")

	rangeHeader := w.Header().Get("Range")
	if rangeHeader != "" {
		http.ServeContent(w, nil, file.Name, fi.ModTime(), f)
	} else {
		io.Copy(w, f)
	}
}

func (h *Handler) serveAudioPreview(w http.ResponseWriter, file *models.File) {
	f, err := os.Open(file.Path)
	if err != nil {
		http.Error(w, "Failed to open file", http.StatusInternalServerError)
		return
	}
	defer f.Close()

	w.Header().Set("Content-Type", file.MimeType)
	io.Copy(w, f)
}

func (h *Handler) serveTextPreview(w http.ResponseWriter, file *models.File) {
	f, err := os.Open(file.Path)
	if err != nil {
		http.Error(w, "Failed to open file", http.StatusInternalServerError)
		return
	}
	defer f.Close()

	content, err := io.ReadAll(f)
	if err != nil {
		http.Error(w, "Failed to read file", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	w.Write(content)
}

func (h *Handler) serveCodePreview(w http.ResponseWriter, file *models.File) {
	f, err := os.Open(file.Path)
	if err != nil {
		http.Error(w, "Failed to open file", http.StatusInternalServerError)
		return
	}
	defer f.Close()

	content, err := io.ReadAll(f)
	if err != nil {
		http.Error(w, "Failed to read file", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	w.Write(content)
}

func (h *Handler) serveDefaultPreview(w http.ResponseWriter, file *models.File) {
	info := map[string]interface{}{
		"name":        file.Name,
		"size":        file.Size,
		"type":        file.MimeType,
		"uploaded_at": file.UploadedAt,
		"message":     "Preview not available for this file type",
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(info)
}

func (h *Handler) GenerateThumbnail(file *models.File) (string, error) {
	if !strings.HasPrefix(file.MimeType, "image/") {
		return "", fmt.Errorf("thumbnail generation not supported for %s", file.MimeType)
	}

	f, err := os.Open(file.Path)
	if err != nil {
		return "", err
	}
	defer f.Close()

	var img image.Image
	switch file.Extension {
	case ".jpg", ".jpeg":
		img, err = jpeg.Decode(f)
	case ".png":
		img, err = png.Decode(f)
	default:
		return "", fmt.Errorf("unsupported image format")
	}

	if err != nil {
		return "", err
	}

	thumbnailPath := filepath.Join(filepath.Dir(file.Path), "thumb_"+file.Name)
	out, err := os.Create(thumbnailPath)
	if err != nil {
		return "", err
	}
	defer out.Close()

	thumb := resizeImage(img, 200, 200)
	jpeg.Encode(out, thumb, nil)

	return thumbnailPath, nil
}

func resizeImage(img image.Image, maxWidth, maxHeight int) image.Image {
	bounds := img.Bounds()
	width := bounds.Dx()
	height := bounds.Dy()

	scale := float64(maxWidth) / float64(width)
	if float64(height)*scale > float64(maxHeight) {
		scale = float64(maxHeight) / float64(height)
	}

	newWidth := int(float64(width) * scale)
	newHeight := int(float64(height) * scale)

	return resize(img, newWidth, newHeight)
}

func resize(img image.Image, width, height int) image.Image {
	result := image.NewRGBA(image.Rect(0, 0, width, height))
	for y := 0; y < height; y++ {
		for x := 0; x < width; x++ {
			sx := x * img.Bounds().Dx() / width
			sy := y * img.Bounds().Dy() / height
			result.Set(x, y, img.At(sx, sy))
		}
	}
	return result
}

func RegisterRoutes(r *http.ServeMux) {
	handler := NewHandler()
	r.Handle("/preview/", http.StripPrefix("/preview", handler))

	logger.Info("Preview routes registered")
}