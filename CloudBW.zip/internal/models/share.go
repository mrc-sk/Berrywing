package models

import (
	"time"

	"gorm.io/gorm"
)

type Share struct {
	ID           uint           `gorm:"primarykey" json:"id"`
	CreatedAt    time.Time      `json:"created_at"`
	UpdatedAt    time.Time      `json:"updated_at"`
	DeletedAt    gorm.DeletedAt `gorm:"index" json:"-"`
	Token        string         `gorm:"size:64;uniqueIndex;not null" json:"token"`
	Name         string         `gorm:"size:255;not null" json:"name"`
	CreatorID    uint           `gorm:"index;not null" json:"creator_id"`
	Creator      *User          `gorm:"foreignKey:CreatorID" json:"creator,omitempty"`
	FileID       *uint          `gorm:"index" json:"file_id"`
	File         *File          `gorm:"foreignKey:FileID" json:"file,omitempty"`
	FolderID     *uint          `gorm:"index" json:"folder_id"`
	Folder       *Folder        `gorm:"foreignKey:FolderID" json:"folder,omitempty"`
	Password     string         `gorm:"size:255" json:"-"`
	IsPublic     bool           `gorm:"default:true" json:"is_public"`
	ExpiresAt    *time.Time     `json:"expires_at"`
	DownloadCount int           `gorm:"default:0" json:"download_count"`
	Views        int            `gorm:"default:0" json:"views"`
}

type Task struct {
	ID           uint           `gorm:"primarykey" json:"id"`
	CreatedAt    time.Time      `json:"created_at"`
	UpdatedAt    time.Time      `json:"updated_at"`
	DeletedAt    gorm.DeletedAt `gorm:"index" json:"-"`
	Type         string         `gorm:"size:50;not null" json:"type"`
	Status       int            `gorm:"default:0" json:"status"`
	UserID       uint           `gorm:"index;not null" json:"user_id"`
	User         *User          `gorm:"foreignKey:UserID" json:"user,omitempty"`
	FileID       *uint          `gorm:"index" json:"file_id"`
	File         *File          `gorm:"foreignKey:FileID" json:"file,omitempty"`
	Source       string         `gorm:"size:2048" json:"source"`
	Destination  string         `gorm:"size:2048" json:"destination"`
	Progress     float64        `gorm:"default:0" json:"progress"`
	ErrorMsg     string         `json:"error_msg"`
	Result       string         `gorm:"type:text" json:"result"`
}

func (Share) TableName() string {
	return "shares"
}

func (Task) TableName() string {
	return "tasks"
}