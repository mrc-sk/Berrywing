package models

import (
	"time"

	"gorm.io/gorm"
)

type File struct {
	ID           uint           `gorm:"primarykey" json:"id"`
	CreatedAt    time.Time      `json:"created_at"`
	UpdatedAt    time.Time      `json:"updated_at"`
	DeletedAt    gorm.DeletedAt `gorm:"index" json:"-"`
	Name         string         `gorm:"size:255;not null" json:"name"`
	Size         int64          `gorm:"not null;default:0" json:"size"`
	Path         string         `gorm:"size:2048" json:"path"`
	ParentID     *uint          `gorm:"index" json:"parent_id"`
	Parent       *Folder        `gorm:"foreignKey:ParentID" json:"parent,omitempty"`
	OwnerID      uint           `gorm:"index;not null" json:"owner_id"`
	Owner        *User          `gorm:"foreignKey:OwnerID" json:"owner,omitempty"`
	PolicyID     uint           `gorm:"index" json:"policy_id"`
	Policy       *StoragePolicy `gorm:"foreignKey:PolicyID" json:"policy,omitempty"`
	MimeType     string         `gorm:"size:255" json:"mime_type"`
	Extension    string         `gorm:"size:50" json:"extension"`
	UploadedAt   time.Time      `json:"uploaded_at"`
	Compressed   bool           `gorm:"default:false" json:"compressed"`
	Encrypted    bool           `gorm:"default:false" json:"encrypted"`
	Thumbnail    string         `gorm:"size:2048" json:"thumbnail"`
	Metadata     string         `gorm:"type:text" json:"metadata"`
}

type Folder struct {
	ID           uint           `gorm:"primarykey" json:"id"`
	CreatedAt    time.Time      `json:"created_at"`
	UpdatedAt    time.Time      `json:"updated_at"`
	DeletedAt    gorm.DeletedAt `gorm:"index" json:"-"`
	Name         string         `gorm:"size:255;not null" json:"name"`
	ParentID     *uint          `gorm:"index" json:"parent_id"`
	Parent       *Folder        `gorm:"foreignKey:ParentID" json:"parent,omitempty"`
	OwnerID      uint           `gorm:"index;not null" json:"owner_id"`
	Owner        *User          `gorm:"foreignKey:OwnerID" json:"owner,omitempty"`
	PolicyID     uint           `gorm:"index" json:"policy_id"`
	Policy       *StoragePolicy `gorm:"foreignKey:PolicyID" json:"policy,omitempty"`
	Path         string         `gorm:"size:2048" json:"path"`
	FileCount    int            `gorm:"default:0" json:"file_count"`
	FolderCount  int            `gorm:"default:0" json:"folder_count"`
	TotalSize    int64          `gorm:"default:0" json:"total_size"`
}

type StoragePolicy struct {
	ID        uint           `gorm:"primarykey" json:"id"`
	CreatedAt time.Time      `json:"created_at"`
	UpdatedAt time.Time      `json:"updated_at"`
	DeletedAt gorm.DeletedAt `gorm:"index" json:"-"`
	Name      string         `gorm:"size:255;not null" json:"name"`
	Type      string         `gorm:"size:50;not null" json:"type"`
	Config    string         `gorm:"type:text" json:"config"`
	IsDefault bool           `gorm:"default:false" json:"is_default"`
	MaxSize   int64          `gorm:"default:10737418240" json:"max_size"`
	Enabled   bool           `gorm:"default:true" json:"enabled"`
}

func (File) TableName() string {
	return "files"
}

func (Folder) TableName() string {
	return "folders"
}

func (StoragePolicy) TableName() string {
	return "storage_policies"
}