package models

import (
	"time"

	"gorm.io/gorm"
)

type User struct {
	ID        uint           `gorm:"primarykey" json:"id"`
	CreatedAt time.Time      `json:"created_at"`
	UpdatedAt time.Time      `json:"updated_at"`
	DeletedAt gorm.DeletedAt `gorm:"index" json:"-"`
	Nickname  string         `gorm:"size:255;not null" json:"nickname"`
	Email     string         `gorm:"size:255;uniqueIndex;not null" json:"email"`
	Password  string         `gorm:"size:255;not null" json:"-"`
	GroupID   uint           `gorm:"index" json:"group_id"`
	Group     *UserGroup      `gorm:"foreignKey:GroupID" json:"group,omitempty"`
	Storage   int64          `gorm:"default:0" json:"storage"`
	MaxStorage int64         `gorm:"default:10737418240" json:"max_storage"`
	Status    int            `gorm:"default:1" json:"status"`
}

type UserGroup struct {
	ID        uint           `gorm:"primarykey" json:"id"`
	CreatedAt time.Time      `json:"created_at"`
	UpdatedAt time.Time      `json:"updated_at"`
	DeletedAt gorm.DeletedAt `gorm:"index" json:"-"`
	Name      string         `gorm:"size:100;not null" json:"name"`
	PolicyID  uint           `gorm:"index" json:"policy_id"`
	Policy    *StoragePolicy  `gorm:"foreignKey:PolicyID" json:"policy,omitempty"`
}

func (User) TableName() string {
	return "users"
}

func (UserGroup) TableName() string {
	return "user_groups"
}