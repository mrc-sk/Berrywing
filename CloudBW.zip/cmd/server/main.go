package main

import (
	"flag"
	"fmt"
	"os"

	"github.com/cloudberrywing/cloudbw/internal/config"
	"github.com/cloudberrywing/cloudbw/internal/plugin"
	"github.com/cloudberrywing/cloudbw/internal/router"
	"github.com/cloudberrywing/cloudbw/internal/services"
	"github.com/cloudberrywing/cloudbw/pkg/logger"
)

var (
	version    = "0.1.0"
	configPath string
)

func init() {
	flag.StringVar(&configPath, "c", "./configs/config.toml", "path to config file")
	flag.Parse()
}

func main() {
	if err := config.LoadConfig(configPath); err != nil {
		fmt.Fprintf(os.Stderr, "Failed to load config: %v\n", err)
		os.Exit(1)
	}

	if err := logger.InitLogger(); err != nil {
		fmt.Fprintf(os.Stderr, "Failed to initialize logger: %v\n", err)
		os.Exit(1)
	}
	defer logger.Sync()

	logger.Info("cloudBerrywing starting...",
		logger.String("version", version),
		logger.String("config", configPath),
	)

	if err := services.InitDatabase(config.Cfg.Database.Path); err != nil {
		logger.Fatal("Failed to initialize database", logger.Error(err))
	}

	initPlugins()
	initLayouts()
	initDownloadManager()

	r := router.SetupRouter()

	addr := fmt.Sprintf("%s:%d", config.Cfg.Server.Host, config.Cfg.Server.Port)
	logger.Info("Server starting", logger.String("address", addr))

	if err := r.Run(addr); err != nil {
		logger.Fatal("Server failed to start", logger.Error(err))
	}
}

func initPlugins() {
	if config.Cfg.Plugin.Enabled {
		if err := plugin.InitPlugins(config.Cfg.Plugin.Dir); err != nil {
			logger.Warn("Failed to initialize plugins", logger.Error(err))
		}
	}
	logger.Info("Plugin system initialized")
}

func initLayouts() {
	plugin.InitDefaultComponents()
	logger.Info("Layout manager initialized with default components")
}

func initDownloadManager() {
	router.InitDownloadManager()
}