# cloudBerrywing (CloudBW)

## 项目概述

cloudBerrywing 是一个用 Go 语言开发的高可定制性开源网盘系统，支持模块化架构设计，像搭积木一样构建你的网盘界面。

## 技术架构

### 后端技术栈

- **语言**: Go 1.21+
- **框架**: Gin Web Framework
- **数据库**: SQLite (默认), 支持 PostgreSQL, MySQL
- **ORM**: GORM
- **日志**: Uber Zap
- **配置**: Spf13 Viper

### 项目结构

```
CloudBW/
├── cmd/
│   ├── server/          # 服务器入口
│   └── cli/             # 命令行工具
├── internal/
│   ├── config/          # 配置管理
│   ├── models/          # 数据模型
│   ├── handlers/        # HTTP 处理器
│   ├── services/        # 业务逻辑层
│   ├── repository/      # 数据访问层
│   ├── middleware/      # 中间件
│   ├── router/          # 路由定义
│   ├── plugin/          # 插件系统
│   ├── webdav/          # WebDAV 支持
│   ├── aria2/           # 离线下载
│   └── preview/         # 文件预览
├── pkg/
│   ├── response/        # 统一响应
│   ├── logger/          # 日志工具
│   └── utils/           # 通用工具
├── configs/             # 配置文件
├── plugins/             # 插件目录
└── web/                 # 前端资源
```

## 功能特性

### 已实现

- ✅ 用户认证 (注册/登录/JWT)
- ✅ 文件上传/下载/删除
- ✅ 文件夹管理
- ✅ 分享链接
- ✅ 存储策略管理
- ✅ 本地存储支持
- ✅ S3 云存储支持
- ✅ **模块化界面系统** - 组件化设计，支持动态布局
- ✅ **WebDAV 支持** - 标准 RFC 4918 协议
- ✅ **离线下载** - 集成 aria2 RPC 客户端
- ✅ **文件预览** - 图片、文档、音视频预览
- ✅ **插件系统** - 支持第三方扩展

### 规划中

- ⏳ 插件热更新
- ⏳ WebDAV ACL 支持
- ⏳ 离线下载任务队列
- ⏳ 文档在线编辑
- ⏳ 多用户协作

## API 接口

### 认证接口

| 方法 | 路径 | 描述 |
|------|------|------|
| POST | /api/v1/auth/register | 用户注册 |
| POST | /api/v1/auth/login | 用户登录 |
| POST | /api/v1/auth/logout | 用户登出 |

### 文件接口

| 方法 | 路径 | 描述 |
|------|------|------|
| GET | /api/v1/files/list | 获取文件列表 |
| POST | /api/v1/files/upload | 上传文件 |
| GET | /api/v1/files/download/:id | 下载文件 |
| DELETE | /api/v1/files/:id | 删除文件 |
| GET | /api/v1/files/preview/:id | 预览文件 |

### 文件夹接口

| 方法 | 路径 | 描述 |
|------|------|------|
| GET | /api/v1/folders/list | 获取文件夹列表 |
| POST | /api/v1/folders/create | 创建文件夹 |
| DELETE | /api/v1/folders/:id | 删除文件夹 |

### 离线下载接口

| 方法 | 路径 | 描述 |
|------|------|------|
| POST | /api/v1/downloads/add | 添加下载任务 |
| GET | /api/v1/downloads/list | 获取下载任务列表 |
| GET | /api/v1/downloads/:gid | 获取任务详情 |
| DELETE | /api/v1/downloads/:gid | 删除下载任务 |
| POST | /api/v1/downloads/:gid/pause | 暂停任务 |
| POST | /api/v1/downloads/:gid/resume | 恢复任务 |

### 插件管理接口

| 方法 | 路径 | 描述 |
|------|------|------|
| GET | /api/v1/plugins/list | 获取插件列表 |
| GET | /api/v1/plugins/:name | 获取插件信息 |
| POST | /api/v1/plugins/:name/enable | 启用插件 |
| POST | /api/v1/plugins/:name/disable | 禁用插件 |

### 布局管理接口

| 方法 | 路径 | 描述 |
|------|------|------|
| GET | /api/v1/layout/components | 获取组件列表 |
| GET | /api/v1/layout/components/:id | 获取组件 Schema |
| POST | /api/v1/layout/pages | 创建页面布局 |
| GET | /api/v1/layout/pages/:id | 获取页面布局 |
| PUT | /api/v1/layout/pages/:id | 更新页面布局 |
| DELETE | /api/v1/layout/pages/:id | 删除页面布局 |
| POST | /api/v1/layout/render/:id | 渲染页面 |

## WebDAV 支持

cloudBerrywing 支持标准 WebDAV 协议，可通过以下地址访问：

```
http://localhost:8080/dav/
```

支持的 WebDAV 方法：
- PROPFIND - 获取资源属性
- MKCOL - 创建目录
- GET - 下载文件
- PUT - 上传文件
- DELETE - 删除资源
- COPY - 复制资源
- MOVE - 移动资源
- LOCK/UNLOCK - 锁定资源

## 离线下载 (aria2)

配置示例：

```toml
[aria2]
enabled = true
endpoint = "http://localhost:6800/jsonrpc"
secret = "your-aria2-secret"
```

支持的下载类型：
- HTTP/HTTPS 下载
- BitTorrent 下载
- Metalink 下载

## 模块化界面系统

### 组件类型

| 类型 | 描述 |
|------|------|
| widget | 小部件（按钮、搜索框等） |
| layout | 布局组件 |
| panel | 面板组件 |
| modal | 模态框 |
| form | 表单组件 |
| list | 列表组件 |
| toolbar | 工具栏 |
| preview | 预览组件 |

### 默认组件

1. **file-list** - 文件列表组件
2. **upload-button** - 上传按钮
3. **storage-info** - 存储信息展示
4. **share-panel** - 分享面板
5. **search-bar** - 搜索栏
6. **preview-modal** - 预览模态框

### 页面布局示例

```json
{
  "id": "dashboard",
  "name": "Dashboard",
  "components": [
    {
      "id": "search-1",
      "component": "search-bar",
      "props": { "placeholder": "Search files..." }
    },
    {
      "id": "storage-1",
      "component": "storage-info",
      "props": { "showPercent": true }
    },
    {
      "id": "files-1",
      "component": "file-list",
      "props": { "viewMode": "grid" }
    }
  ]
}
```

## 插件系统

### 插件接口

```go
type Plugin interface {
    Name() string
    Version() string
    Description() string
    Init() error
    Shutdown() error
}
```

### UI 组件插件

```go
type UIComponent interface {
    Plugin
    Render(ctx context.Context) (string, error)
    GetComponentName() string
    GetComponentCategory() string
}
```

### 存储驱动插件

```go
type StorageDriver interface {
    Plugin
    GetStorageType() string
}
```

## 快速开始

### 环境要求

- Go 1.21+
- GCC (用于 SQLite)
- aria2 (可选，用于离线下载)

### 编译运行

```bash
cd CloudBW
go mod tidy
go build -o cloudbw ./cmd/server
./cloudbw -c ./configs/config.toml
```

### 默认配置

- 地址: http://0.0.0.0:8080
- 默认管理员: admin@cloudbw.local / admin123

## 配置说明

配置文件位于 `configs/config.toml`:

```toml
[server]
host = "0.0.0.0"
port = 8080
mode = "debug"

[database]
type = "sqlite"
path = "./data/cloudbw.db"

[storage]
provider = "local"
path = "./storage"

[aria2]
enabled = false
endpoint = "http://localhost:6800/jsonrpc"

[plugin]
enabled = false
dir = "./plugins"
```

## 开发指南

### 添加新的组件

1. 定义组件 Schema
2. 在 `internal/plugin/layout.go` 中注册组件
3. 实现组件渲染逻辑

### 添加新的插件

1. 实现 `Plugin` 接口
2. 编译为 `.so` 文件
3. 放入 `plugins/` 目录

### 代码规范

- 遵循 Go 官方代码规范
- 使用 `gofmt` 格式化代码
- 单元测试覆盖率 > 70%

## License

MIT License
